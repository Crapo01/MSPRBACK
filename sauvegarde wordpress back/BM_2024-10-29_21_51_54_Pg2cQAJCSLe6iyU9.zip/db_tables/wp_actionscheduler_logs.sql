/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_actionscheduler_logs`; */
/* PRE_TABLE_NAME: `1730238718_wp_actionscheduler_logs`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1730238718_wp_actionscheduler_logs` ( `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `action_id` bigint(20) unsigned NOT NULL, `message` text NOT NULL, `log_date_gmt` datetime DEFAULT '0000-00-00 00:00:00', `log_date_local` datetime DEFAULT '0000-00-00 00:00:00', PRIMARY KEY (`log_id`), KEY `action_id` (`action_id`), KEY `log_date_gmt` (`log_date_gmt`)) ENGINE=InnoDB AUTO_INCREMENT=226 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1730238718_wp_actionscheduler_logs` (`log_id`, `action_id`, `message`, `log_date_gmt`, `log_date_local`) VALUES (221,168,'action créée','2024-10-29 19:57:40','2024-10-29 20:57:40'),(222,169,'action créée','2024-10-29 19:57:48','2024-10-29 20:57:48'),(223,170,'action créée','2024-10-29 19:57:48','2024-10-29 20:57:48'),(224,171,'action créée','2024-10-29 21:49:53','2024-10-29 22:49:53'),(225,172,'action créée','2024-10-29 21:50:29','2024-10-29 22:50:29');
