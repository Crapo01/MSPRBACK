/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_terms`; */
/* PRE_TABLE_NAME: `1730238718_wp_terms`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1730238718_wp_terms` ( `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `name` varchar(200) NOT NULL DEFAULT '', `slug` varchar(200) NOT NULL DEFAULT '', `term_group` bigint(10) NOT NULL DEFAULT 0, PRIMARY KEY (`term_id`), KEY `slug` (`slug`(191)), KEY `name` (`name`(191))) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1730238718_wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES (1,'Non classé','non-classe',0),(2,'twentytwentyfour','twentytwentyfour',0),(3,'twentytwentytwo','twentytwentytwo',0),(4,'simple','simple',0),(5,'grouped','grouped',0),(6,'variable','variable',0),(7,'external','external',0),(8,'exclude-from-search','exclude-from-search',0),(9,'exclude-from-catalog','exclude-from-catalog',0),(10,'featured','featured',0),(11,'outofstock','outofstock',0),(12,'rated-1','rated-1',0),(13,'rated-2','rated-2',0),(14,'rated-3','rated-3',0),(15,'rated-4','rated-4',0),(16,'rated-5','rated-5',0),(17,'Non classé','non-classe',0),(18,'navigation principale','navigation-principale',0);
