/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_wc_customer_lookup`; */
/* PRE_TABLE_NAME: `1730238718_wp_wc_customer_lookup`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1730238718_wp_wc_customer_lookup` ( `customer_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `user_id` bigint(20) unsigned DEFAULT NULL, `username` varchar(60) NOT NULL DEFAULT '', `first_name` varchar(255) NOT NULL, `last_name` varchar(255) NOT NULL, `email` varchar(100) DEFAULT NULL, `date_last_active` timestamp NULL DEFAULT NULL, `date_registered` timestamp NULL DEFAULT NULL, `country` char(2) NOT NULL DEFAULT '', `postcode` varchar(20) NOT NULL DEFAULT '', `city` varchar(100) NOT NULL DEFAULT '', `state` varchar(100) NOT NULL DEFAULT '', PRIMARY KEY (`customer_id`), UNIQUE KEY `user_id` (`user_id`), KEY `email` (`email`)) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1730238718_wp_wc_customer_lookup` (`customer_id`, `user_id`, `username`, `first_name`, `last_name`, `email`, `date_last_active`, `date_registered`, `country`, `postcode`, `city`, `state`) VALUES (1,1,'admin','','','petitcrapo@hotmail.com','2024-06-29 14:44:09','2024-05-31 04:11:38','FR',21541,'jk',''),(2,2,'client','df','dfs','client@client.com','2024-10-03 00:00:00','2024-09-19 07:33:40','FR',21541,'jk','');
