/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wptm_wc_category_lookup`; */
/* PRE_TABLE_NAME: `1730238718_wptm_wc_category_lookup`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1730238718_wptm_wc_category_lookup` ( `category_tree_id` bigint(20) unsigned NOT NULL, `category_id` bigint(20) unsigned NOT NULL, PRIMARY KEY (`category_tree_id`,`category_id`)) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
