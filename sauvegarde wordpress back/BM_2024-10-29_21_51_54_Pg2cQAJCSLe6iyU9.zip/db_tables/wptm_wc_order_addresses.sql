/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wptm_wc_order_addresses`; */
/* PRE_TABLE_NAME: `1730238718_wptm_wc_order_addresses`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1730238718_wptm_wc_order_addresses` ( `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `order_id` bigint(20) unsigned NOT NULL, `address_type` varchar(20) DEFAULT NULL, `first_name` text DEFAULT NULL, `last_name` text DEFAULT NULL, `company` text DEFAULT NULL, `address_1` text DEFAULT NULL, `address_2` text DEFAULT NULL, `city` text DEFAULT NULL, `state` text DEFAULT NULL, `postcode` text DEFAULT NULL, `country` text DEFAULT NULL, `email` varchar(320) DEFAULT NULL, `phone` varchar(100) DEFAULT NULL, PRIMARY KEY (`id`), UNIQUE KEY `address_type_order_id` (`address_type`,`order_id`), KEY `order_id` (`order_id`), KEY `email` (`email`(191)), KEY `phone` (`phone`)) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
