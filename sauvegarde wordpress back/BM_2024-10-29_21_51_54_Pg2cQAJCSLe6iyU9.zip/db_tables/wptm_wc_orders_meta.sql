/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wptm_wc_orders_meta`; */
/* PRE_TABLE_NAME: `1730238718_wptm_wc_orders_meta`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1730238718_wptm_wc_orders_meta` ( `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `order_id` bigint(20) unsigned DEFAULT NULL, `meta_key` varchar(255) DEFAULT NULL, `meta_value` text DEFAULT NULL, PRIMARY KEY (`id`), KEY `meta_key_value` (`meta_key`(100),`meta_value`(82)), KEY `order_id_meta_key_meta_value` (`order_id`,`meta_key`(100),`meta_value`(82))) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
