/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wptm_wc_product_meta_lookup`; */
/* PRE_TABLE_NAME: `1730238718_wptm_wc_product_meta_lookup`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1730238718_wptm_wc_product_meta_lookup` ( `product_id` bigint(20) NOT NULL, `sku` varchar(100) DEFAULT '', `global_unique_id` varchar(100) DEFAULT '', `virtual` tinyint(1) DEFAULT 0, `downloadable` tinyint(1) DEFAULT 0, `min_price` decimal(19,4) DEFAULT NULL, `max_price` decimal(19,4) DEFAULT NULL, `onsale` tinyint(1) DEFAULT 0, `stock_quantity` double DEFAULT NULL, `stock_status` varchar(100) DEFAULT 'instock', `rating_count` bigint(20) DEFAULT 0, `average_rating` decimal(3,2) DEFAULT 0.00, `total_sales` bigint(20) DEFAULT 0, `tax_status` varchar(100) DEFAULT 'taxable', `tax_class` varchar(100) DEFAULT '', PRIMARY KEY (`product_id`), KEY `virtual` (`virtual`), KEY `downloadable` (`downloadable`), KEY `stock_status` (`stock_status`), KEY `stock_quantity` (`stock_quantity`), KEY `onsale` (`onsale`), KEY `min_max_price` (`min_price`,`max_price`), KEY `sku` (`sku`(50))) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
